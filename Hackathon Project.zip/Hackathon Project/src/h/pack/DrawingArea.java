/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package h.pack;

import java.awt.Graphics;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import h.pack.MainFrame;
/**
 *
 * @author liang
 */
public class DrawingArea extends javax.swing.JPanel {
    Timer timer; // timer for updating the screen
    
    public DrawingArea() {
        initComponents();
        setFocusable(true); // make the panel focus
        timer = new Timer(10, new DrawingArea.TimeListener());
        timer.start();
    }
    
    private class TimeListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            repaint();
        }
    }
    
    String[] questionArray = {
        "What kind of transportation do you regularly use?", // radio buttons 0
        // Small - Minicars, smartcars, coup-like
        // Medium - Sedan-like
        // Large - Minivan, Pickup-Truck
        // EV, bike, scooter, walk
        // Public Transportation
        "How far do you commute on average each week in km?", // slider 1
        "How many people typically drive together in the vehicle?", // radio button 2
        // Conditional qn, if answered small, med, large
        "How many hours do you typically fly a year?", // slider 3
        "What type of flights do you take?", // radio buttons
        // Conditional qn, if answered more than 0 in last one
        // Domestic (state, province, territories)
        // Regional (country-wide)
        // International (world-wide)
        "What does your meat consumption look like per week?", // radio buttons
        // Daily meat
        // Avg diet (meat few times a week)
        // Pescatarian
        // Vegetarian
        // Vegan
        "How much of the food you eat is unprocessed, unpackaged, or locally grown?", // slider
        "How often do you buy new clothing?", // radio buttons
        // Frequent (weekly - monthly)
        // Seasonal (3-4 times a year)
        // Minimal and second-hand
        "Which housing type best describes your home?", // radio buttons
        // Small / Apt (<1200sqft = <112sqm)
        // Medium house (1200 - 2500sqft = 112 - 232 sqm)
        // Large house (>2500sqft = >232sqm)
        "How many people live in your household?", // radio buttons
        "How much of your house's electricity comes from renewable sources?", // slider
        "Compared to your neighbours, how much trash do you generate per person?", // radio buttons
        // Below avg
        // Avg (706kg/year in CAN)
        // Above Avg
    };
    
    int curQuestion = 0;
    String [][] minMax = {
        {"0", "100"}, // radio button
        {"0", "1000+"},
        {"0", "100"}, // radio button
        {"0", "100+"},
        {"0", "100"}, // radio button
        {"0", "100"}, // radio button
        {"0%", "100%"},
        {"0", "100"}, // radio button
        {"0", "100"}, // radio button
        {"0", "100"}, // radio button
        {"0%", "100%"},
        {"0", "100"} // radio button
    };
    int [] valueArray = new int [questionArray.length];
    static boolean quesAnswered = false;
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Font f = new Font("Tempus Sans", Font.BOLD, 18);
        g.setFont(f);
        g.drawString("Carbon Footprint Tracker", 300, 50);
        Font f2 = new Font("Tempus Sans", Font.PLAIN, 16);
        g.setFont(f2);
        try {
            g.drawString(questionArray[curQuestion].substring(0,
                    questionArray[curQuestion].indexOf((' '), 50) + 1),
                    300, 100);
            g.drawString(questionArray[curQuestion].substring
        (questionArray[curQuestion].indexOf((' '), 50) + 1),
                    300, 120);
        } catch (Exception e) {
            g.drawString(questionArray[curQuestion], 300, 100);
        }
        if (curQuestion == 0 || curQuestion == 2 || curQuestion == 4 || curQuestion == 5 ||
                curQuestion == 7 || curQuestion == 8 || curQuestion == 9 || curQuestion == 11){
            MainFrame.slider.setVisible(false);
            MainFrame.jRadioButton1.setVisible(true);
            MainFrame.jRadioButton2.setVisible(true);
            MainFrame.jRadioButton3.setVisible(true);
            MainFrame.jRadioButton4.setVisible(true);
            MainFrame.jRadioButton5.setVisible(true);
            switch (curQuestion) {
                case 0:
                    setText(MainFrame.jRadioButton1, "Small Vehicle (Eg. Coupe-like, mini, smartcar)");
                    setText(MainFrame.jRadioButton2, "Medium Vehicle (Eg. Sedan-like)");
                    setText(MainFrame.jRadioButton3, "Large Vehicle (Eg. SUV-like, minivan, pickup truck)");
                    setText(MainFrame.jRadioButton4, "Transportation that don't use fuel (Eg. Electric Vehicle, Bike)");
                    setText(MainFrame.jRadioButton5, "Public Transit (Eg. buses, subway, train)");
                    break;
                case 2: // conditional
                    setText(MainFrame.jRadioButton1, "1 - 2");
                    setText(MainFrame.jRadioButton2, "3 - 4");
                    setText(MainFrame.jRadioButton3, "5 - 6");
                    setText(MainFrame.jRadioButton4, "7 - 8");
                    setText(MainFrame.jRadioButton5, "9+");
                    break;
                case 4: // conditional
                    setText(MainFrame.jRadioButton1, "Domestic");
                    setText(MainFrame.jRadioButton2, "Regional");
                    setText(MainFrame.jRadioButton3, "International");
                    MainFrame.jRadioButton4.setVisible(false);
                    MainFrame.jRadioButton5.setVisible(false);
                    break;
                case 5:
                    setText(MainFrame.jRadioButton1, "Daily Meat Consumption");
                    setText(MainFrame.jRadioButton2, "Meat few times a week");
                    setText(MainFrame.jRadioButton3, "Pescatarian");
                    setText(MainFrame.jRadioButton4, "Vegetarian");
                    setText(MainFrame.jRadioButton5, "Vegan");
                    break;
                case 7:
                    setText(MainFrame.jRadioButton1, "Frequent(weekly/monthly)");
                    setText(MainFrame.jRadioButton2, "Seasonal(3-4 times a year)");
                    setText(MainFrame.jRadioButton3, "Minimal or second hand");
                    MainFrame.jRadioButton4.setVisible(false);
                    MainFrame.jRadioButton5.setVisible(false);
                    break;
                case 8:
                    setText(MainFrame.jRadioButton1, "Small / Apt (<1200sqft = <112sqm)");
                    setText(MainFrame.jRadioButton2, "Medium house (1200 - 2500sqft = 112 - 232 sqm)");
                    setText(MainFrame.jRadioButton3, "Large Vehicle Large house (>2500sqft = >232sqm)");
                    MainFrame.jRadioButton4.setVisible(false);
                    MainFrame.jRadioButton5.setVisible(false);
                    break;
                case 9:
                    setText(MainFrame.jRadioButton1, "1-3");
                    setText(MainFrame.jRadioButton2, "4-6");
                    setText(MainFrame.jRadioButton3, "7-9");
                    setText(MainFrame.jRadioButton4, "10+");
                    MainFrame.jRadioButton5.setVisible(false);
                    break;
                case 11:
                    setText(MainFrame.jRadioButton1, "Below avg");
                    setText(MainFrame.jRadioButton2, "Avg (706kg/year in CAN)");
                    setText(MainFrame.jRadioButton3, "Above avg");
                    MainFrame.jRadioButton4.setVisible(false);
                    MainFrame.jRadioButton5.setVisible(false);
                    break;
                default:
                    break;
            }
            buttonSelection();
        } else {
            MainFrame.slider.setVisible(true);
            MainFrame.jRadioButton1.setVisible(false);
            MainFrame.jRadioButton2.setVisible(false);
            MainFrame.jRadioButton3.setVisible(false);
            MainFrame.jRadioButton4.setVisible(false);
            MainFrame.jRadioButton5.setVisible(false);
            
            g.drawString(minMax[curQuestion][0], 300, 180);
            g.drawString(minMax[curQuestion][1], 655, 180);
            valueArray[curQuestion] = MainFrame.slider.getValue();
            if (curQuestion == 1) {
                valueArray[curQuestion] *= 10;
            }
        }
        
        // next question
        if (quesAnswered) {
            System.out.println(valueArray[curQuestion]);
            curQuestion++;
            quesAnswered = false;
        }
    }
    double[][] assignment = {
        {2.5, 1.8, 1.4, 1.0, 0.7},
        {1.75, 1, 0.5},
        {3, 2, 1}
    };
    void setText(javax.swing.JRadioButton x, String y){
        x.setText(y);
    }
    
    void buttonSelection () {
        if (MainFrame.jRadioButton1.isSelected()) {
            valueArray[curQuestion] = 0;
        } else if (MainFrame.jRadioButton2.isSelected()) {
            valueArray[curQuestion] = 1;
        } else if (MainFrame.jRadioButton3.isSelected()) {
            valueArray[curQuestion] = 2;
        } else if (MainFrame.jRadioButton4.isSelected()) {
            valueArray[curQuestion] = 3;
        } else if (MainFrame.jRadioButton5.isSelected()) {
            valueArray[curQuestion] = 4;
        }
    }
    double driveConversion (double factor, int distance) {
        double tCO2e = (distance * 52 * factor)/1000;
        return tCO2e;
    }
    double flightConversion (double factor, int hours){
        double tCO2e = (hours * factor)/1000;
        return tCO2e;
    }
    double foodConversion (){
        double tCO2e = assignment[0][curQuestion];
        return tCO2e;
    }
    double clothingConversion (){
        double tCO2e = assignment[1][curQuestion];
        return tCO2e;
    }
    double houseConversion (){
        double tCO2e = assignment[2][curQuestion];
        return tCO2e;
    }
    double renewableEnergy (int renewablePerc) {
        double tCO2e = renewablePerc/-50;
        return tCO2e;
    }
    double trashConversion (){
        double tCO2e = 0;
        switch (valueArray[curQuestion]) {
            case 0 -> tCO2e = -1;
            case 1 -> tCO2e = 0;
            case 2 -> tCO2e = 1;
            default -> {
            }
        }
        return tCO2e;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
